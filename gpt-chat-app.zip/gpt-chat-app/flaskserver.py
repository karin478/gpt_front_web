import os
import openai
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

app = Flask(__name__, static_folder='build/static')
CORS(app, resources={r"/*": {"origins": "*"}})

openai.api_key = "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"
openai.organization = "org-lCrqbZ89jcATFDeZXNs9LobT"

def generate_chat_response(prompt):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ],
        temperature=0.7
    )

    return response.choices[0].message.content.strip()

@app.route('/api/completions', methods=['POST'])
def completions():
    data = request.json
    prompt = data.get('prompt')

    if prompt is None:
        return jsonify({"error": "Missing 'prompt' parameter"}), 400

    response = generate_chat_response(prompt)
    return jsonify({"response": response})

@app.route('/api/verify_password', methods=['POST'])
def verify_password():
    password = request.json.get('password')
    correct_password = 'xieping'  # 请将 'your_password' 替换为您选择的密码
    if password == correct_password:
        return jsonify({'authenticated': True})
    else:
        return jsonify({'authenticated': False})

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve_static(path):
    if path != "" and os.path.exists(os.path.join("build", path)):
        return send_from_directory('build', path)
    else:
        return send_from_directory('build', 'index.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3003)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3003)
