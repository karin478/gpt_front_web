const express = require("express");
const axios = require("axios");
const cors = require("cors");
const dotenv = require("dotenv");

dotenv.config();

const app = express();
app.use(express.json());
app.use(cors());

app.post("/api/completions", async (req, res) => {
  const { model, messages, max_tokens, temperature, top_p, frequency_penalty, presence_penalty } = req.body;

  try {
    const response = await axios.post(
      "https://api.openai.com/v1/engines/davinci/completions",
      {
        prompt: `${messages.map((msg) => `${msg.role}: ${msg.content}`).join("\n")}\nassistant:`,
        max_tokens,
        temperature,
        top_p,
        frequency_penalty,
        presence_penalty,
      },
      {
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        },
      }
    );

    res.json(response.data);
  } catch (error) {
    console.error("Error fetching GPT response:", error);
    res.status(500).json({ message: "Error fetching GPT response." });
  }
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
