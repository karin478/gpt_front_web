import os
import openai

openai.api_key = "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"
openai.organization = "org-lCrqbZ89jcATFDeZXNs9LobT"

def generate_chat_response(prompt):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ],
        temperature=0.7
    )

    return response.choices[0].message.content.strip()

prompt = "Translate the following English text to French: 'Hello, how are you?'"
response = generate_chat_response(prompt)
print(response)
