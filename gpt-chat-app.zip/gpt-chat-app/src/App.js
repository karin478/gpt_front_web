import React, { useState } from 'react';
import './App.css';
import Chat from './Chat';
import axios from 'axios';

function App() {
  const [password, setPassword] = useState('');
  const [authenticated, setAuthenticated] = useState(false);

  const handlePasswordSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://20.120.5.236:3:3003/api/verify_password', { password });
      if (response.data.authenticated) {
        setAuthenticated(true);
      } else {
        alert('Incorrect password. Please try again.');
      }
    } catch (error) {
      console.error('Error verifying password:', error);
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>KarinGPT</h1>
        {authenticated ? (
          <Chat />
        ) : (
          <form onSubmit={handlePasswordSubmit}>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter password"
            />
            <button type="submit">Submit</button>
          </form>
        )}
      </header>
    </div>
  );
}

export default App;
