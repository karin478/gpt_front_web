import React, { useState, useRef } from 'react';
import axios from 'axios';
import './Chat.css';
import { Light as SyntaxHighlighter } from 'react-syntax-highlighter';
import { docco } from 'react-syntax-highlighter/dist/esm/styles/hljs';

const Chat = () => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const messagesEndRef = useRef(null);

  const codeRegex = /```([\s\S]*?)```/g;
  const tableRegex = /^\s*\|(.+\|)+\s*$/;

  const scrollToBottom = () => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (input.trim() === "") return;

    setMessages([...messages, { role: "user", content: input }]);
    setInput("");

    try {
      const response = await axios.post("http://127.0.0.1:3003/api/completions", {
        prompt: input,
      });

      const assistantMessage = response.data.response;
      setMessages((prevMessages) => [
        ...prevMessages,
        { role: "assistant", content: assistantMessage },
      ]);
      scrollToBottom(); // 添加这一行
    } catch (error) {
      console.error("Error fetching GPT response:", error);
    }
  };

  const handleReset = () => {
    setMessages([]);
    scrollToBottom(); // 添加这一行
  };

  const renderMessage = (message) => {
    const codeMatch = message.content.match(codeRegex);
    const tableMatch = message.content.split('\n').some((line) => tableRegex.test(line));

    if (codeMatch) {
      // ...省略
    } else if (tableMatch) {
      return <div dangerouslySetInnerHTML={{ __html: convertTableToHTML(message.content) }} />;
    } else {
      return message.content;
    }
  };

  const convertTableToHTML = (tableText) => {
    const rows = tableText.split('\n');
    const headerRow = rows.shift(); // Remove header row
    const separatorRow = rows.shift(); // Remove separator row

    const tableHeaders = headerRow.split('|').slice(1, -1);

    let tableHTML = '<table><thead><tr>';
    tableHeaders.forEach((header) => {
      tableHTML += `<th>${header.trim()}</th>`;
    });
    tableHTML += '</tr></thead><tbody>';

    rows.forEach((row) => {
      if (row.trim() === '' || !tableRegex.test(row)) return;
      const rowData = row.split('|').slice(1, -1);
      tableHTML += '<tr>';
      rowData.forEach((data) => {
        tableHTML += `<td>${data.trim()}</td>`;
      });
      tableHTML += '</tr>';
    });

    tableHTML += '</tbody></table>';
    return tableHTML;
  };


  return (
    <div className="Chat-container">
      <ul className="message-list">
        {messages.map((message, index) => (
          <li key={index} className={message.role === "user" ? "user-message" : "assistant-message"}>
            <strong>{message.role}:</strong> {renderMessage(message)}
          </li>
        ))}
      </ul>
      <div ref={messagesEndRef}></div> {/* 添加这一行 */}
      <form onSubmit={handleSubmit} className="message-form">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type your message here..."
          className="message-input"
        />
        <button type="submit" className="send-button">Send</button>
        <button onClick={handleReset} className="reset-button">Reset Chat</button>
      </form>
    </div>
  );
  
};

export default Chat;
